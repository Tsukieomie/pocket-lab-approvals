# Location drain keepalive — Pocket Lab v3.0
if ! busybox ps | grep -v grep | grep -q location-drain; then
    /usr/local/bin/location-drain &
    echo $! > /tmp/location.pid
fi
