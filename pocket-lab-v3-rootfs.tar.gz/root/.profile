# Pocket Lab v3.0 — root profile
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
if ! busybox ps | grep -v grep | grep -q location-drain; then
    /usr/local/bin/location-drain &
    echo $! > /tmp/location.pid
fi
[ -f /root/perplexity/AUTO_START.sh ] && sh /root/perplexity/AUTO_START.sh
